/**
* @author  : Harish Subramanium
*
* Makes webpack config's based on the passed parameters and returns a config that can be used by webpack
*/

"use strict";

var fs = require('fs');
var path = require('path');

var _ = require('lodash');
var webpack = require('webpack');
var rimraf = require('rimraf');

var workingDirectory = path.join(__dirname, '../public/');
var outputDirectoryRoot = path.join(__dirname, '../dist');

// Delete the output folder path, since it'll be regenerated from scratch
rimraf.sync(outputDirectoryRoot);
fs.mkdirSync(outputDirectoryRoot);

module.exports = function(buildConfig) {

  // Default buildConfig vals. These are the keys that can be passed through.
  buildConfig = _.assign({
    devtool: "sourcemap",
    watch: false,
    debug: false,
    minimize: false,
    bail: false
  }, buildConfig);

  var minimize = buildConfig.minimize;

  var loaders = [

    // Javascript and jsx assets
    {
      test: /\.js$/,
      exclude: /(node_modules|Uranium)/,
      loader: "babel-loader"
    }, {
      test: /\.jsx?$/,
      exclude: /(node_modules|Uranium)/,
      loader: "babel-loader"
    },
    // Typescript
    {
      test: /\.ts$/,
      exclude: /(node_modules|Uranium)/,
      loader: 'ts-loader?configFile=public/tsconfig.json&transpileOnly=true'
    },
    {
      test: /\.tsx?$/,
      loader: 'ts-loader?configFile=public/tsconfig.json&transpileOnly=true'
    },

    // Handling CSS assets
    {
      test: /\.scss$/,
      loaders: [
        'style',
        'css-loader?-minimize',
        'sass-loader?outputStyle=compressed'
      ]
    },

    {
      test: /\.css$/,
      loaders: [
        'style',
        'css-loader?minimize'
      ]
    },

    // Handling image assets
    { test: /(\.png|\.gif|\.jpg|\.jpeg)$/, loaders: ['url'] },

    // Handling webfonts
    { test: /(\.woff|\.eot|\.svg|\.ttf)($|\?)/, loaders: ['url'] },

    // Handling JSON
    { test: /\.json$/, loaders: ['json'] },

    // Handling HTML
    { test: /\.html$/, loaders: ['html'] },

    // Vue
    {
      test: /\.vue$/,
      loader: 'vue-loader',
      options: {
        loaders: {
          'scss': 'vue-style-loader!css-loader!sass-loader',
          'sass': 'vue-style-loader!css-loader!sass-loader?indentedSyntax'
        }
      }
    }
  ];

  if (minimize) {
    loaders[0].loader += '!strip?strip[]=console.log,strip[]=console.info,strip[]=console.debug,strip[]=console.warn,strip[]=console.error';
  }

  var preloaders = [
    // import angular into other dependent libraries
    { test: /angular-.+\.js$/, loader: 'imports?angular=angular' },
  ];

  var resolve = {
    root: [workingDirectory],
    modulesDirectories: ["javascripts", "node_modules", "stylesheets"],
    extensions: ['.js', '.jsx', '.scss', '.ts', '.tsx', '.jsx', '.html', ''],
    alias: {
      // Internal Package maps
      // External Package maps
      controls: path.join(__dirname, '../public/javascripts/forms/controls')
    }
  };

  var externals = [{
    "ga": true,

    // Browser specific global's required for jsx and jsNext files
    window: true,
    document: true
  }];

  // Ignores these modules from the node_modules folder. Significantly speeds up build and re-build time
  // especially when using file watching.
  var noParse = [];

  var entry = {
    // Javascript entry points for each platform
    "main": "./tools/platforms/browser",
    "node": "./tools/platforms/node",
    "native": "./tools/platforms/native"
  };

  var output = {
    path: outputDirectoryRoot,
    pathinfo: !buildConfig.minimize,

    // The main bootstrap file has the chunkhash appended to it as a query string.
    // It dosen't serve any purpose at the moment, but once webpack handles the HTML assets as well
    // we can add the hash to the filename here as well.
    filename: '[name].js' + (buildConfig.minimize ? "?[chunkhash]" : ""),

    // Chunk filename has the hash defined as part of the filename
    chunkFilename: buildConfig.minimize ? '[name].js' : '[id].js',
    crossOriginLoading: "anonymous",
    publicPath: buildConfig.publicPath ? buildConfig.publicPath : void 0
  };

  var node = {
    global: true,

    path: false,
    timers: false,
    Buffer: false,
    process: false,
    fs: false
  };

  // Delete the output folder path, since it'll be regenerated from scratch
  rimraf.sync(output.path);

  // Any legacy AMD modules should be defined here
  var amd = {};

  var plugins = [

    // When code is minimized, this feature flag is set which can be used to optionally enable / disable features
    new webpack.DefinePlugin({
      __PROD__: buildConfig.minimize,
      "process.env": { NODE_ENV: JSON.stringify(process.env.NODE_ENV || 'production') },
      __WEBPACK_LIVE__: JSON.stringify(process.env.__WEBPACK_LIVE__ || false),
      __HTTPS__: JSON.stringify(process.env.__HTTPS__ || false)
    }),

    // Prevent moment from including all locales' :-|
    new webpack.ContextReplacementPlugin(/moment[\/\\]locale$/, /en/),

    // Global moment <-> moment-timezone
    new webpack.ProvidePlugin({
      "moment": "moment-timezone"
    })
  ];

  if(buildConfig.minimize) {

    plugins = plugins.concat([

      new webpack.optimize.DedupePlugin(),

      new webpack.optimize.OccurenceOrderPlugin(),

      new webpack.optimize.UglifyJsPlugin({
        compress: true,
        mangle: true,
        output: { comments: false },
        warning: true
      })
    ]);
  }

  var config = {
    context: process.cwd(),
    entry: entry,
    bail: buildConfig.bail,
    devtool: buildConfig.devtool,
    debug: buildConfig.debug,
    watch: buildConfig.watch,
    cache: {},
    node: node,
    amd: amd,
    module: {
      loaders: loaders,
      preLoaders: preloaders,
      noParse: noParse
    },
    plugins: plugins,
    resolve: resolve,
    externals: externals,
    output: output
  };

  // Print's the final config out to stdout. (For debugging purposes if required)
  // console.debug("\nConfig Options --> \n", JSON.stringify(config, null, 4), "\n");

  return config;
};
