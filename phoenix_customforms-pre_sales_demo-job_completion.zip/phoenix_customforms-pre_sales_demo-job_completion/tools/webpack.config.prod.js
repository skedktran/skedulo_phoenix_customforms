module.exports = require('./make.webpack.config.js')({
  minimize: true
});