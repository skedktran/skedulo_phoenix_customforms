module.exports = {
  "extends": [
    // "frack", // eslint-config-frack
  ],
  "parserOptions": {
    "parser": 'babel-eslint',
    "ecmaVersion": 6,
    "sourceType": "module",
    "ecmaFeatures": {
      "jsx": true
    }
  },
  "rules": {
    "semi": "warn",
    "eol-last": "warn"
  }
};
