const fs = require('fs');

const clearIds = (filename) => {
  const filePath = `./custom_field_config/${filename}.json`;

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) throw err;

    let jsonData = JSON.parse(data);
    jsonData.forEach(item => delete item.id);

    fs.writeFile(filePath, JSON.stringify(jsonData), 'utf8', (err) => {
      if (err) throw err;

      console.log(filePath + ' <-- saved.')
    })
  });
};

['fields', 'schemas'].forEach(clearIds);