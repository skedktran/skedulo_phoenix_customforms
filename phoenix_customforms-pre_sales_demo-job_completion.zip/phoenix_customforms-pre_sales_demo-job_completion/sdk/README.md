# Sked-CLI
Collection of command-line-tools to talk to Skedulo
