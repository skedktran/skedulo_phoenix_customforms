import React from 'react';
import styled from 'styled-components';

import * as color from './color';

export const NoResult = styled.div`
  text-align: center;
  color: #cecece;
  font-size: 17.5px;
  padding: 10px 0;
  min-height: inherit
`;

export const OverlayBackground = styled.div`
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(179, 179, 179, 0.3);
    z-index: 99;
  `;

export const PopupPanel = styled.div`
    width: 80vw;
    margin: 0 auto;
    background: ${color.colorWhite};
    border-radius: 20px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 1px 1px 30px #ccc;
  `;

export const PopupButtons = styled.div`
    width: 100%;
    height: 50px;
    margin-top: 16px;
    
    button {
      height: 50px;
      background: transparent;
      border-color: ${color.colorLightGrey};
      color: ${color.colorGreen};
      font-size: 16px;
    }
  `;

export const PopupButton1 = styled.button`
    border-width: 1px 1px 0 0;
  `;
export const PopupButton2 = styled.button`
    border-width: 1px 0 0 0;
  `;