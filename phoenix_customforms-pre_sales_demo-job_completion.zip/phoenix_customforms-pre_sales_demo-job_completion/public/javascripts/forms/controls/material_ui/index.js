import React from 'react';
import TextField from "material-ui/TextField"
import SelectField from "material-ui/SelectField"
import MenuItem from "material-ui/MenuItem"

export class CustomTextField extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: props.value || ''
    }
  }

  render() {
    const textFieldOpts = {
      floatingLabelFixed: true,
      fullWidth: true,
      hintStyle: {
        fontSize: '12px'
      },
      floatingLabelStyle: {},
      inputStyle: {
        boxShadow: 'none !important'
      },
      underlineStyle: {
        boxSizing: 'border-box'
      },
      underlineFocusStyle: {
        boxSizing: 'border-box',
        borderBottomWidth: '1px'
      },
      autoComplete: 'skedulo',
      rows: this.props.multiLine ? 3 : 1,
      multiLine: this.props.multiLine,
      id: Date.now().toString(),
      errorText: this.props.errorText
    };

    return <div className="list-item rm-pad-b">
      <div className={this.props.col || 'col-12'}>
        <label style={{marginBottom: 0}} htmlFor={textFieldOpts.id}>{this.props.caption}</label>
        <TextField {...textFieldOpts} hintText={this.props.hintText} floatingLabelText="" value={this.state.value}
                   onChange={(evt, val) => this.onChangeHandler(val)}/>
      </div>
    </div>
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      value: nextProps.value || ''
    });
  }

  onChangeHandler(val) {
    let value = val;
    if (this.props.maxLength) {
      value = val.substr(0, this.props.maxLength)
    }

    this.props.onChange(value)
  }
}

export class CustomSelect extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: props.value || ''
    }
  }

  render() {
    const textFieldOpts = {
      floatingLabelFixed: true,
      fullWidth: true,
      hintStyle: {
        fontSize: '12px'
      },
      floatingLabelStyle: {},
      inputStyle: {
        boxShadow: 'none'
      },
      underlineStyle: {
        boxSizing: 'border-box'
      },
      underlineFocusStyle: {
        boxSizing: 'border-box',
        borderBottomWidth: '1px'
      },
      autoComplete: 'skedulo',
      id: Date.now().toString(),
      errorText: this.props.errorText
    };

    return <div className="list-item rm-pad-b">
      <div className={this.props.col || 'col-12'}>
        <label style={{marginBottom: 0}} htmlFor={textFieldOpts.id}>{this.props.caption}</label>
        <SelectField {...textFieldOpts} hintText={this.props.hintText} floatingLabelText="" value={this.props.value}>
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          {this.props.options.map(item => <MenuItem onClick={() => this.props.onChange(item)} key={item.value}
                                                    primaryText={item.label} value={item.value}/>)}
        </SelectField>
      </div>
    </div>
  }
}