import React from 'react';
import {Textbox} from "../../controls/react";

export default class SkedSignaturePanel extends React.Component {
  render() {
    const {allowDelete, readOnly, caption, value, sign, dirty, SignaturePanel, nameChangedHandler, signHandler, setError} = this.props;
    const onSignatureAction = () => {
      if (!value) {
        setError();
      } else {
        return SignaturePanel().then(signHandler);
      }
    };
    return <div>
      <div className="form-group-container__col">
        <label className={`form-group-label col-8 rm-margin-t`}>
          <Textbox caption={caption} value={value} onChange={val => nameChangedHandler(val)} required={false} dirty={dirty} disabled={readOnly}/>
        </label>
        {!readOnly && <button className={"btn btn--block col-4 mg-t-70 rm-pad-all" + (value ? " btn--green" : " btn--gray")} onClick={() => onSignatureAction()}><i className="sk sk-sig"/> Sign</button>}
      </div>
      {value && <div className="form-group-container__col pad-v rm-pad-b">
        {<div className="image-upload-preview">
          {!readOnly && allowDelete && <div className="delete-icon-wrapper" onClick={(evt) => {
            if (readOnly) return;
            evt.stopPropagation();
            signHandler('');
          }}>
            {sign && <i className="sk sk-close-circle"/>}
          </div>}
          <img src={sign} alt=""/>
        </div>}
      </div>}

      <div className="clearfix"></div>
    </div>;
  }
}
