import React, {useState} from 'react';
import styled from "styled-components";
import {PopUp} from "./panel"

export const Lookup2 = (props) => {
  const {caption, options, value, displayField, onClick, disabled} = props;
  const [showLookup, setShowLookup] = useState(false);
  const [term, setTerm] = useState("");

  return <div>
    <div className="form-group-container__col">
      <label className={`form-group-label`}>{caption}</label>
        <div className={`lookup`} onClick={() => setShowLookup(!disabled)}>
          <div className="form-control">
            <span>{value || ""}</span>
          </div>
        </div>
      </div>

    {showLookup && <PopUp title="Select" buttons={[]}>
      <div className="lookup-wrapper rm-pad-all">
        <SearchWrapper>
          <SearchBox type="text" required value={term} onChange={val => setTerm(val.target.value)} />
          <SearchBoxPlaceholder className="search-box-placeholder">Type something to search</SearchBoxPlaceholder>
        </SearchWrapper>

        {options.filter(item => term ? (isInclude(item.Name)) : true).map((item, idx) => (
          <SearchItem key={idx} className="list-item hasArrow" onClick={(evt) => {
              onClick(item);
              setShowLookup(false);
            }}>
            <span className="">{item[displayField || "Name"]}</span>
          </SearchItem>))
        }
      </div>
    </PopUp>}
  </div>;
};

const SearchWrapper = styled.div`
    position: relative;
    padding: 0 20px;
    margin-bottom: 16px;
    margin-top: 16px;
  `;

const SearchBox = styled.input`
  border: none !important;
  border-radius: 4px !important;
  background: none !important;
  background-color: #ebedf0 !important;
  width: 100% !important;
  height: 48px !important;
  padding: 20px !important;
  box-shadow: none !important;
  font-size: 13.3333px !important;

  &:focus,
  &:valid {
    &+.search-box-placeholder {
      display: none !important;
    }
  }
`;

const SearchItem = styled.div`
  line-height: 23px;
`;

const SearchBoxPlaceholder = styled.div`
  pointer-events: none;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  font-size: 13px;
  color: #B3b3B3;

  &:before {
    content: '';
    position: absolute;
    top: calc(50% + 3px);
    left: -29px;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 19px;
    height: 19px;
  }
`;
