import React from 'react';
import {Select, Textarea, Textbox, Toggle} from "./input";
import {MultiPicklist, ListRadioInline, Rating} from "./others";
import {datetimeLocalFormat, dateFormat} from "../../constant";
import _SkedSignaturePanel from "./signature"
import {SkedDatePicker} from "./datetime"
// import {DateTimeSelect as DateTimeSelect1, TimePicker, DateTimePicker} from "./datetime"

export * from "./input"
export * from "./table"
export * from "./panel"
export * from "./lookup"
export * from "./others"
export * from "./googleLocation"
export * from "./addressAutocomplete"
export * from "./lookup2"
export * from "./datetime"
export const SkedSignaturePanel = _SkedSignaturePanel;

// export const DateTimeSelect = (value, onChange) => <DateTimeSelect1 value={value} onChange={onChange}/>

export const SkedConrol = ({caption = "", model = {}, setModel, type = "", ...options}) => {
  let {prop, maxLength, vocabularies, options: _customValues} = options || {};
  prop = prop || formatPropName(caption);
  vocabularies = vocabularies || {};
  
  const updateModelHandler = (val) => setModel({...model, [prop]: val});

  const _options = {...options,
    caption,
    placeholder: options.placeholder || ""
  }
  
  switch (type) {
    case 'textarea': 
      return <Textarea {..._options} value={model[prop]}  onChange={val => updateModelHandler(val)} maxLength={maxLength || 32768} />;
    case 'datetime': 
      const dateTimeValue = model[prop] ? moment(model[prop]).format(datetimeLocalFormat) : null;
      return <Textbox {..._options} type="datetime-local" value={dateTimeValue}  onChange={val => updateModelHandler(prop, moment(val, datetimeLocalFormat))} />;
    case 'date': 
      return <SkedDatePicker value={model[prop]} onChange={val => updateModelHandler(val)} {..._options}/>
    case 'number': 
      return <Textbox {..._options} type="number" value={model[prop]}  onChange={val => updateModelHandler(val)} />;
    case 'email': 
      return <Textbox {..._options} type="email" value={model[prop]}  onChange={val => updateModelHandler(val)} />;
    case 'picklist': 
      return <Select {..._options} options={vocabularies[prop] || _customValues} value={model[prop]}  onChange={val => updateModelHandler(val)} />;
    case 'multipicklist': 
      return <MultiPicklist {..._options} options={vocabularies[prop] ? vocabularies[prop].map(item => item.value) : _customValues} value={model[prop]}  onChange={val => updateModelHandler(val)} />;
    case 'boolean': 
      return <Toggle {..._options} value={model[prop]} onChange={val => updateModelHandler(val)} />;
    case 'radio-inline': 
      return <ListRadioInline {..._options} value={model[prop]} options={vocabularies[prop] ? vocabularies[prop].map(item => item.value) : _customValues} onChange={val => updateModelHandler(val)} />;
    case 'rating':
      return <Rating {..._options} ratings={_customValues} star={model[prop]} onChange={rating => updateModelHandler(rating)}/>;
  }

  return <Textbox {..._options} value={model[prop]}  onChange={val => updateModelHandler(val)} maxLength={maxLength || 255} />;
};

const formatPropName = (str = "") => {
  return str.replace(/(?:^\w|[A-Z]|\b\w)/g, word => word.toUpperCase()).replace(/\s+/g, '').replace(/,|\?|\//g, '');
};