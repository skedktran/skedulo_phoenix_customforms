import DataHelper from '../dataHelper';
// import * as mockData from './mock'
import {
  objectToManaged,
  managedItemsToObject
} from '@skedulo/uranium';

import {userJobQuery} from "./query"

if (!global || !global._babelPolyfill) {
  require('babel-polyfill');
}

export default wrapper;

function wrapper(httpLibs, utils) {

  const dataHelper = new DataHelper(httpLibs, utils);
  const graphiQl = dataHelper.getGraphiQlInstance();

  async function fetch(jobIds) {
    return Promise
      .all([
        dataHelper.fetchData('Jobs', `UID IN $1`, [jobIds]),
        // dataHelper.fetchAttachmentLists(jobIds)
        //   .then(attachmentList => dataHelper.fetchAttachmentData(attachmentList.filter(item => item.name.includes('job_completion_')))),
        dataHelper.fetchPublishUrl(jobIds)
      ])
      .then(([jobs, attachments]) => buildDataStruct(jobIds, _.keyBy(jobs, "UID"), attachments))
  }

  function buildDataStruct(jobIds, jobs, attachments) {

    const retObj = jobIds
      .map(jobId => {

        const obj = {
          jobId, job: objectToManaged(jobs[jobId] || {}),
          attachments: attachments.filter(item => item.parentId === jobId && item.fileName.includes('job_completion_')).map(objectToManaged)
        };

        return { [jobId]: obj };
      })
      .reduce((acc, e) => _.assign(acc, e), {});

    return {
      main: retObj,
      common: { }
    };
  }

  async function fetchCache() {
    return Promise.resolve({text: "Hello world !!!"});
  }

  function save(data) {
      return saveBulk([data]);
  }
  function saveBulk(saveArray) {
    const cleaned = _.compact(saveArray);

    const jobIds = _.uniq(_.flatten(cleaned.map(items => Object.keys(items))));
    const jobItems = _.compact(_.flatten(_.flatten(cleaned.map(items => _.values(items))).map(i => i.jobs)))
    const attachments = _.compact(_.flatten(_.flatten(cleaned.map(items => _.values(items))).map(i => i.attachments)))

    return saveItems(jobIds, jobItems, attachments);
  }

  function saveItems(jobIds, jobItems, attachments) {
    return dataHelper.saveAttachments(attachments)
      .then(() => dataHelper.createUpdate("Jobs", jobItems))
      .then(() => fetch(jobIds))
      .then(result => _.pick(result, 'main'));
  }

  function saveItems1(jobIds, changSetObj) {
    return graphiQl.executeBulkMutation(graphiQl.mutationFactory('Jobs', changSetObj))
      .then(() => fetch(jobIds))
      .then(result => _.pick(result, 'main'));
  }

  return { fetch, save, saveBulk, fetchCache };

}
