import * as React from 'react';
import * as ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import {transitionGroup} from "../../constant"

import {constant} from './duck/action';

import Landing from './landing'

export default ({view}: any): any => {
  return (
    <div>
      <ReactCSSTransitionGroup {...transitionGroup}>

        {view === constant.VIEW_HOME && <Landing/>}

      </ReactCSSTransitionGroup>
    </div>
  )
}