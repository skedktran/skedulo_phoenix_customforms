import * as React from 'react';
import {useState, useEffect} from "react";
import {useSelector, useDispatch} from "react-redux";
import styled from "styled-components";
import {StoreState} from "./duck/type";
import {
  SkedConrol, SkedSignaturePanel, PopUp
} from "../../controls/react";
import {saveDataToSf, saveAttachments} from "./duck/action"

const descriptionIcon = require("../../../../stylesheets/static/forms/images/description.svg")
const signatureIcon = require("../styles/signature.png");

interface Props {
  job: any,
  widgets: any,
  attachmenObj: any
}

export default ({}) => {
  const dispatch = useDispatch();
  const {job, widgets, attachmenObj}: Props = useSelector(({reducer}: StoreState) => {
    return {
      job: reducer.managedJob.listAll()[0],
      attachmenObj: reducer.managedAttachments.listAll()[0],
      widgets: reducer.widgets
    }
  })
  const attachmentPreview = attachmenObj ? (attachmenObj.attachment || attachmenObj.downloadUrl) : ""
  // state intial value only matter only for the first render
  // so move it into function will prevent issue with accesing unknown property in subsequence call
  const [description, setDescription] = useState<string>(() => job.Description)
  const [completionNotes, setCompletionNotes] = useState<string>(() =>job.CompletionNotes)
  const [name, setName] = useState<string>(() => attachmenObj ? attachmenObj.fileName.substring(15, attachmenObj.fileName.length - 4) : "")
  const [preview, setPreview] = useState<string>(attachmentPreview);

  const [confirm, setConfirm] = useState<boolean>(() => job.Confirm)
  const [rate, setRate] = useState(() =>({
    Rating: job.Rating
  }))

  const [showSignature, setShowSignature] = useState<boolean>(false)
  const [confirmSignature, setConfirmSignature] = useState<boolean>(() => !!attachmenObj)

  const [showEdit, setShowEdit] = useState<string>("")
  const [text, setText] = useState<any>({
    text: ""
  });



  const [error, showError] = useState<boolean>(false)
  
  const onSaveHandler = () => {
    if (confirm && rate.Rating && name && preview) {
      // dispatch(saveAttachments({
      //   name, attachment: preview
      // }))
      dispatch(saveDataToSf({
        attachment: {
          name,
          signature: attachmentPreview !== preview ? preview : '' // to avoid updating attachment if signature is not changed
        },
        job: {
          Description: description,
          CompletionNotes: completionNotes,
          Rating: rate.Rating,
          Confirm: confirm
        }
      }))
    } else {
      showError(true);
    }
  }
  
  return <div>
    <div>
      <div className="content-section">
        <CompletionNotes className="key-value-item__key color-grey">Description</CompletionNotes>
        <div className="key-value-item__value card-body color-darkgrey pad-v" onClick={() => {
          setShowEdit("Description")
          setText({
            text: description
          })
        }}>{description}</div>
      </div>

      <div className="content-section">
        <CompletionNotes className="key-value-item__key color-grey">Completion Notes</CompletionNotes>
        <div className="key-value-item__value card-body color-darkgrey pad-v" onClick={() => {
          setShowEdit("Completion Notes")
          setText({
            text: completionNotes
          })
        }}>{completionNotes}</div>
      </div>

      <div className="content-section">
        <div className="form-group-container__col">
          <div className="form-element__multiple-container form-element__multiple-container--checkbox">

            <div className="form-element__multiple form-element__multiple--checkbox">
              <input className="form-element__multiple-input form-element__multiple-input--checkbox"
                    checked={confirm}
                    type="checkbox" id={"checkbox"} name="multiple" value={true}
                    onChange={evt => setConfirm(evt.target.checked)}/>
              <label htmlFor={"checkbox"}
                    className="confirm-checkbox form-element__multiple-label form-element__multiple-label--checkbox">I confirm the work described above has been completed.</label>
            </div>
          </div>
        </div>
      </div>

      <div className="content-section">
        <SkedConrol type="rating" caption="How would you rate today's service?" prop="Rating" model={rate} setModel={setRate} required options={[1, 2, 3, 4, 5]}/>
      </div>

      <div className="content-section">
        <label htmlFor="confirm" className=" color-darkgrey ">
                Please provide a signature to confirm completion of this job.</label>
        <SignatureBox className="image-upload-preview rm-margin-b" onClick={() => setShowSignature(true)} confirmSignature={confirmSignature} sign={preview} name={name}></SignatureBox>
      </div>

      <div className="pad-all">
        <button className="btn btn--block btn--green" onClick={() => onSaveHandler()}>Save</button>  
      </div>
      

      {showSignature && <PopUp title="Capture signature"
                          buttons={[{
                            action: () => setShowSignature(false),
                            caption: 'Close'
                          }, {
                            primary: true,
                            action: () => {
                              setShowSignature(false)
                              setConfirmSignature(true)
                            },
                            caption: 'Confirm'
                          }]}>
                             {/*
                              // @ts-ignore */}
                              <SkedSignaturePanel caption={`Signature`} value={name} sign={preview} readOnly={false} SignaturePanel={widgets.SignaturePanel} allowDelete={true}
                                            setError={() => {}} nameChangedHandler={(val: string) => setName(val)} signHandler={(val: string) => setPreview(val)}/>
                          </PopUp>}

      {showEdit && <PopUp title={"Capture " + showEdit}
                                  buttons={[{
                                    action: () => setShowEdit(""),
                                    caption: 'Close'
                                  }, {
                                    primary: true,
                                    action: () => {
                                      if (showEdit === "Description") {
                                        setDescription(text.text)
                                      } else {
                                        setCompletionNotes(text.text)
                                      }
                                      setShowEdit("")
                                    },
                                    caption: 'Confirm'
                                  }]}>
                             <SkedConrol type="textarea" prop="text" model={text} setModel={setText}  placeholder={"Enter"}/>
                      </PopUp>}

      {error && <PopUp title={"Please input required fields "}
                  buttons={[{
                    action: () => showError(false),
                    primary: true,
                    caption: 'Close'
                  }]}>
              <span>Please confirm and rate!</span>
      </PopUp>}
    </div>
  </div>
}
//
const SignatureBox = styled.div`
  padding: 1rem;
  border: 1px dashed #eee;
  height: 120px;
  position: relative;
  &::before {
    content: '';
    width: 100%;
    height: 100%;
    background: #fff url(${prop => !prop.confirmSignature ? signatureIcon : prop.sign}) no-repeat;
    background-position:  50% ${prop => prop.confirmSignature ? '50%' : '0'};
    background-size: ${({confirmSignature}) => confirmSignature ? 'contain' : 'inital'} ;
  }

  &::after {
    content: "${prop => !prop.confirmSignature ? 'Capture signature' : prop.name}";
    position: absolute;
    bottom: 0;
  }
`;

const CompletionNotes = styled.div`
  background: #fff url(${descriptionIcon}) no-repeat;
  padding-left: 30px;
`;

const Name = styled.div`
  font-size: large;
  font-weight: 500;
`;

const Wrapper = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  border-bottom: 1px #ddd solid;
  padding-bottom: 10px;
  padding: 16px;
`;

const Title = styled.div`
  
`;

const TitleWrapper = styled.div`
    
`;

const IconWrapper = styled.div`
  background-color: #59B66E;
  padding: 16px;
  border-radius: 5px;
  margin-right: 10px;
`;