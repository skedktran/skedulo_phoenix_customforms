import * as React from 'react';
import Header from './header'
import Routers from './router'
import {GoBackConfirmModal} from "../../controls/react";
import {connect} from 'react-redux';

interface MainState {
  showConfirm?: boolean,
  showLoading?: boolean,
  dimension?: number
}

interface MainProps {
  formSaveFunc?: any,
  jobId: string,
  view: string
}

class Main extends React.Component<MainProps, MainState> {

  state: MainState = {
    showConfirm: false,
    showLoading: false,
    dimension: Main.getDimension()
  }

  render() {
    return (
      <div>
        <Header onSaveFn={this.saveFn.bind(this)} onGobackFn={this.goBackFn.bind(this)} showConfirm={() => this.setState({showConfirm: true})}/>
        <section>
          {/*------------------ common items ---------------------*/}
          <div className="scroll-touch" style={{overflowY: "scroll"}}>
            <Routers view={this.props.view}/>
          </div>
        </section>

        <GoBackConfirmModal show={this.state.showConfirm} onConfirmGoBack={val => this.confirmGoBack(val)}/>
        <div className={`modal ${this.state.showLoading && 'active'}`}>
          <div className="prompt" style={{background: 'transparent', textAlign: 'center'}}>
            <div className="lds-ring">
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  goBackFn() {
    // if (this.props.photoShoots.changeSet().length) {
    //   this.setState({showConfirm: true})
    // } else {
    //   window.navGoBack();
    // }

    this.setState({showConfirm: true})
  }

  saveFn() {
    this.props.formSaveFunc({
      jobId: this.props.jobId
    }, {
      jobId: this.props.jobId
    })
  }

  // ------------ private function -------------- //

  confirmGoBack(confirm: boolean) {
    this.setState({
      showConfirm: confirm
    })
  }

  componentDidMount() {
    window.addEventListener('orientationchange', () => this.handleScreenRotate(), false);
    this.handleScreenRotate()
  }

  handleScreenRotate() {
    this.setState({dimension: Main.getDimension()});
    this.forceUpdate()
  }

  static getDimension() : number {
    if (window.orientation !== 0) {
      return 1 // types.DIMENSION.landscape
    }
    return 0 // types.DIMENSION.portrait
  }
}

export default connect((state: any) => ({
  view: state.reducer.view
}))(Main)