import * as React from 'react'
import {useState, useEffect} from "react"
import {PopUp} from "../../controls/react";
import {useSelector, useDispatch} from "react-redux"
import {saveDataToSf, setView, constant} from "./duck/action";

export default ({onGobackFn}) => {
  const dispatch = useDispatch();
  const props = useSelector(({reducer}: any) => {
    return {
      view: reducer.view,
      job: reducer.main.job
    }
  });

  useEffect(() => {
     // register back button for andoid device
     let count = 1;
     const interval = setInterval(() => {
       if (count === 10) {
         clearInterval(interval);
       }
       if (typeof window.ContainerRegisterBackButtonHandler === 'function') {
         window.ContainerRegisterBackButtonHandler(() => onGoBackHandler());
         clearInterval(interval);
       }
       count++;
     }, 1000);
  });

  const number = 7;
  const information = buildInformation();
  const [title, setTitle] = useState("Job Completion");
  const [description, setDescription] = useState(props.job.Name);
  const [headerClickCount, setHeaderClickCount] = useState(0);
  const [timeout, setTimeoutNumber] = useState<any>(-1)

  const onGoBackHandler = () => {
    if (props.view === constant.VIEW_HOME) {
      // window.navGoBack();

      onGobackFn();
    } else {
      switch (props.view) {
        // case constant.VIEW_DETAIL: dispatch(setView({view: constant.VIEW_MUST_READ_INFORMATION})); break;

        default:
          dispatch(setView({view: constant.VIEW_HOME}));
      }
    }
  }

  const onHeaderClickHandler = (_headerClickCount) => {
    if (_headerClickCount < number) {
      _headerClickCount += 1;
      clearTimeout(timeout);
      setHeaderClickCount(_headerClickCount);
    } else {
      setHeaderClickCount(number);
    }

    setTimeoutNumber(setTimeout(() => {
      if (headerClickCount < number - 1) {
        setHeaderClickCount(0);
      } 
    }, 2000));
  };

  return (
    <header className="bar-title">
      <button className="btn color-white transparent fl" onClick={() => onGoBackHandler()}>
        <i className="sk sk-chevron-left"/>
      </button>

      <h1 className="title" onClick={() => onHeaderClickHandler(headerClickCount)}><span>{title}</span></h1>
      <h2 className="header-description">{description}</h2>

      {/* {props.view === constant.VIEW_HOME &&
      <button className="btn color-white transparent fr" onClick={() => dispatch(saveDataToSf({}))}>
        Save
      </button>} */}

      {headerClickCount === number && (
        <PopUp title="Form Information"
               buttons={[{
                 primary: true,
                 action: () => setHeaderClickCount(0),
                 caption: 'Close'
               }]}><div dangerouslySetInnerHTML={{__html: information}} /></PopUp>)}
    </header>
  );
};

const buildInformation = () => {
  const infoData = require('../../../../build-info/latest.json');
  let information = `<div class="text-left">`;
  information += Object.keys(infoData).reduce((result, key) => ([...result, `<strong>${key}</strong>`, `${infoData[key]}`]), []).join(`<br />`);
  information += `</div>`;
  return information;
};
