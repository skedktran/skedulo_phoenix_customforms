import {AppState, AppAction} from './type';
import {constant} from './action'
import { DataManager } from '@skedulo/uranium';

export default function reducer(state: AppState = {
  timestamp: Date.now(),
  main: {},
  common: {},
  saveFn: () => {},
  view: constant.VIEW_HOME
}, action: AppAction): AppState {
  switch (action.type) {
    case constant.ACTION_INIT_DATA: {
      const {main, common, saveFn, widgets, deviceCache} = action.params;

      const managedJob = new DataManager([main.job])
      const managedAttachments = new DataManager(main.attachments)

      return {
        ...state, main, common, saveFn, widgets, deviceCache, managedJob,
        timestamp: Date.now(), managedAttachments
      };
    }
    case constant.ACTION_SET_VIEW: {
      const {params} = action;
      return {
        ...state,
        view: params.view
      };
    }
    case constant.ACTION_SET_SELECTED_ITEM: {
      const {params} = action;
      return {
        ...state,
        selectedItem: {...params.item}
      };
    }
    
    case constant.ACTION_SAVE_DATA_TO_SALESFORCE: {
      const {job, attachment} = action.params

      const {name, signature} = attachment;
      const existings = state.managedAttachments.listAll();

      // to avoid updating attachment if signature is not changed
      if (signature) {
        existings.forEach(attachment => {
          state.managedAttachments.deleteItem(attachment.UID)
        });
        state.managedAttachments.createNew({
          parentId: state.main.jobId,
          attachment: signature,
          name: `job_completion_${name.replace(/ /g, "_")}.png`
        })
      }

      state.managedJob.editItem(state.main.jobId, {...job})

      state.saveFn({
        jobId: state.main.jobId,
        jobs: state.managedJob.changeSet(),
        attachments: state.managedAttachments.changeSet()
      }, {
        jobId: state.main.jobId,
        job: state.managedJob.listAll()[0],
        attachments: state.managedAttachments.listAll()
      }, false, true);

      return {...state};
    }
  }

  return state;
}