export interface AppState {
  main: any,
  common: any,
  saveFn: any,
  view: string,
  selectedItem?: any,
  managedJob?: any,
  managedAttachments?: any,

  timezone?: string,
  timestamp?: any

  widgets?: any,
  deviceCache?: any
}

export interface AppAction {
  type: string,
  params: any
}

export interface StoreState {
  reducer: AppState
}