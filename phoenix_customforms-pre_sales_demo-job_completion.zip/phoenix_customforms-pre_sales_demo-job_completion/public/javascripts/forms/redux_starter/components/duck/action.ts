export const constant = {
  VIEW_HOME: 'VIEW_HOME',
  VIEW_DETAIL: 'VIEW_DETAIL',

  ACTION_INIT_DATA: 'INIT_DATA',
  ACTION_SET_VIEW: 'SET_VIEW',
  ACTION_SAVE_DATA_TO_SALESFORCE: 'ACTION_SAVE_DATA_TO_SALESFORCE',
  ACTION_SET_SELECTED_ITEM: 'SET_SELECTED_ITEM',
  ACTION_SAVE_ATTACHMENT: 'ACTION_SAVE_ATTACHMENT'
}

const createSimpleAction = (type: string) => (params: any) => (dispatch: any, getState: any) => dispatch({type, params});

export const setView = createSimpleAction(constant.ACTION_SET_VIEW);
export const setSelectedItem = createSimpleAction(constant.ACTION_SET_SELECTED_ITEM);
export const saveDataToSf = createSimpleAction(constant.ACTION_SAVE_DATA_TO_SALESFORCE);
export const saveAttachments = createSimpleAction(constant.ACTION_SAVE_ATTACHMENT);