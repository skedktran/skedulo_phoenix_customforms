import 'sass/skedulo-mobile';
import 'signature/index';

import React from 'react';
import ReactDOM from 'react-dom';
import MainComponent from './components/main';
import {Provider} from "react-redux";
import store from "./store";
import {constant} from "./components/duck/action";
import GraphiQLHelper from '../graphiQlHelper';

export default function wrapper(currentJobId, formSaveFunc, widgets, onLoadCallback = () => console.info('--> View Ready <--')) {

  window.onerror = function (message, file, line, col, error) {
      alert("Error occurred: " + error.message);
      return false;
  };

  return function(formData, deviceCache) {
    // console.log('initApp', formData, currentJobId);

    const {main, common} = formData;
    const graphiQl = new GraphiQLHelper();

    if (location.protocol.indexOf('http') > -1) {
      widgets.TakePhoto = widgets.GetFromGallery = widgets.SignaturePanel;
      widgets.GraphQL = ({query, variables}) => graphiQl.executeQuery(query, variables).then(res => res.data);
    }

    // format query data
    widgets.originGrapthQl = widgets.GraphQL;
    widgets.GraphQL = (parameters) => widgets.originGrapthQl(parameters).then(graphiQl.formatResponseData)

    store.dispatch({
      type: constant.ACTION_INIT_DATA,
      params: {main, common, saveFn: formSaveFunc, widgets, deviceCache}
    });

    ReactDOM.render(<Provider store={store}>
      <MainComponent />
    </Provider>, document.getElementById('root'), () => {
      onLoadCallback();
    });
  }
}