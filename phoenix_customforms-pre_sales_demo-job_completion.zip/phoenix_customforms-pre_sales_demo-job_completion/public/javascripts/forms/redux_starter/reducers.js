import {combineReducers} from "redux";

import reducer from "./components/duck/reducer";

export default combineReducers({
  reducer
})