import _ from 'lodash';
import {managedItemsToObject, PermissionsService} from '@skedulo/uranium';
import GraphiQLHelper from './graphiQlHelper';

export default class DataHelper {

  constructor(httpLibs, utils) {
    const {http, httpAPI, Query} = httpLibs;
    const {fetchAsDataURI, fetchUserAvatars} = utils;

    this.httpAPI = httpAPI;
    this.http = http;
    this.Query = Query;
    this.fetchAsDataURI = fetchAsDataURI;
    this.fetchUserAvatars = fetchUserAvatars;
    this.permissionService = new PermissionsService(http);
  }

  getGraphiQlInstance() {
    if (!this.graphiQl) {
      this.graphiQl = new GraphiQLHelper(this.httpAPI, this.http);
    }
    return this.graphiQl;
  }

  bulkQuery(objName, filter, filterParams, ...otherFilterParams) {
    let arr = [];

    while (filterParams.length > 100) {
      arr.push(filterParams.splice(0, 100));
    }

    arr.push(filterParams.splice(0));

    const promises = arr.map(item => fetchData(objName, filter, [].concat([item]).concat(otherFilterParams)));

    return Promise.all(promises).then(result => {
      return _.flatten(result);
    });
  }

  fetchData(objName, filter, filterParams, withFields, onlyFields) {
    const Query = this.Query;
    let query = new Query().limit(5000);

    if (filter) {
      query = query.filter(filter, filterParams || []);
    }

    if (withFields) {
      query = query.withFields(withFields).onlyFields(!!onlyFields);
    }

    return query
      .makeRequest(this.httpAPI, objName)
      .then(res => res.records);
  }

  fetchNestedObj(objNeedPermissions, test = false) {
    const objCruds = this.createCrudArray(objNeedPermissions);

    if (test) {

      return Promise.all(objNeedPermissions.map((crud, index) => this.fetchData(crud).then(res => ({[objNeedPermissions[index]]: res}))))
        .then((results) => _.assign({}, ...results));
    }

    return Promise.all(objCruds.map((crud, index) => this.crudFetchData(crud).then(res => ({[objNeedPermissions[index]]: _.keyBy(res, 'UID')}))))
      .then((results) => _.assign({}, ...results));

  }

  createCrudArray(objNames) {
    return objNames.map(name => this.permissionService.createCrudService(name, this.httpAPI));
  }

  getPermissions(objNames) {
    return this.permissionService.getPermissionsFor(...objNames);
  }

  crudFetchData(crud, filter, filterParams, withFields, onlyFields = false) {
    if (withFields && withFields.length > 200) {
      let fields = _.reject([...withFields], item => item === "UID");
      let arr = []

      while (fields.length > 200) {
        arr.push(["UID", ...fields.splice(0, 200)])
      }
  
      arr.push(["UID", ...fields.splice(0)])

      const promises = arr.map(fieldItems => this.executeCrudFetch(crud, filter, filterParams, fieldItems, true))
      return Promise.all(promises).then(result => {
        const resultData = result.splice(0, 1)[0];

        _.each(result, items => {
          _.each(resultData, dataItem => {
            const existItem = items.find(i => i.UID === dataItem.UID)
            if (existItem) {
              _.assign(dataItem, existItem)
            }
          })
        })

        return resultData;
      })

    }
    return this.executeCrudFetch(crud, filter, filterParams, withFields, onlyFields) 
  }

  executeCrudFetch(crud, filter, filterParams, withFields, onlyFields = false) {
    return crud.fetch(query => {
      query = query.limit(5000);
      return query.filter(filter || "UID != ''", filterParams || [])
    }, true, withFields ? _.compact(withFields) : null).then(res => res.records)
  }

  // contacts: [{ClientPhotoId, contactId }]
  fetchClientAvatars(contacts) {
    return Promise.all(contacts
      .filter(item => !!item.ClientPhotoId)
      .map(item => this.fetchAsDataURI(`/attachment/${item.ClientPhotoId}`, this.http)
        .then(base64 => ({[item.UID]: base64}))))
      .then(([...photos]) => _.assign({}, ...photos));
  }

  //users: [{UID, SmallPhotoUrl}]
  fetchAvatars(users) {
    if (users.length === 0) {
      return Promise.resolve({});
    }

    const splitArray = (items) => {
      let promises = [];
      const itemNumber = 50;

      while (items.length > itemNumber) {
        promises.push(items.splice(0, itemNumber));
      }
      promises.push(items.splice(0, items.length));

      return promises;
    };

    return Promise.all([this.fetchUserAvatars([users[0].UID], this.http)])
      .then(([firstResult]) => {
        const promises = splitArray(users.slice(1).map(item => item.UID));
        return Promise.all(promises.map(idArr => this.fetchUserAvatars(idArr, this.http)))
          .then(result => _.assign({}, ...firstResult, ...result))
          .catch(() => {
          });
      })
      .catch(() => {
        const promises = splitArray(users);
        return Promise.all(promises.map(items => this.fetchClassicUserAvatars(items))).then((result) => _.assign({}, ...result))
          .catch(() => {
          });
      });
  }

  // fetch attachmend/ photo from salesforce
  fetchBulkDataFromSf(urls) {
    const promises = urls.map(url => this.fetchAsDataURI.get(`../proxy?target=${url}`).then(result => ({
      url,
      data: result.data
    })));
    return Promise.all(promises);
  }

  // fetch pre-authorisation from salesforce
  fetchPublishUrl(parentIds) {
    if (parentIds.length === 0) {
      return Promise.resolve({})
    }
    return this.http.get("/files/attachments?parent_ids=" + parentIds.join(','))
      .then(res => _.flatten(_.toArray(res.data.result)).map(item => ({UID: item.filePtr, ...item})))
  }

  // fetchAvatars(userIds) {
  //   let promises = [];
  //
  //   while (userIds.length > 50) {
  //     promises.push(userIds.splice(0, 50));
  //   }
  //   promises.push(userIds.splice(0, userIds.length));
  //
  //   return Promise.all(promises.map(idArr => this.fetchUserAvatars(idArr, this.http)))
  //     .then(result => _.assign({}, ...result));
  // }

  getVocabularies() {
    return new Promise((resolve, reject) => {
      this.http.get("/custom/vocabularies")
        .then(res => resolve(res.data.result))
        .catch(() => this.http.get("/vocabulary").then(res => resolve(res.data)));
    });
  }

  getVocabulary(objectName) {
    return this.getSchemaFields(objectName).then(data => {
      const picklists = data.filter(item => item.type === "picklist").map(item => ({[item.label]: item.values}));
      return _.assign({}, ...picklists);
    });
  }

  getUsermetadata() {
    return new Promise((resolve, reject) => {
      this.http.get("/custom/usermetadata")
        .then(res => resolve(res.data.result))
        .catch(() => this.http.get("/usermetadata").then(res => resolve(res.data)));
    });
  }

  getSchemaFields(objectName) {
    return this.http.get(`/custom/metadata/${objectName}`)
      .then(res => res.data.result.fields);
  }

  getSchemas() {
    return Promise.all([
      this.http.get(`/custom/schemas`).then(res => res.data.result),
      this.http.get(`/custom/standard_schemas`).then(res => res.data.result)
    ]).then(([...results]) => [].concat(...results));
  }

  getFields() {
    return this.http.get(`/custom/fields`).then(res => res.data.result);
  }

  crudUpdate(crud, diffs) {
    if (diffs.length === 0) return Promise.resolve({});
    return crud.update(diffs, true).then(res => res.data);
  }

  crudCreate(crud, objs) {
    if (objs.length === 0) return Promise.resolve({});
    return crud.create(objs, true).then(res => res.data);
  }

  crudCreateUpdate(crud, objs, mapObj) { // mapObj: {{idMaps, field: 'IncidentReportId'}}
    const {added, updated, deleted, addedItems, updatedItems} = managedItemsToObject(objs);

    if (mapObj) {
      added.forEach(item => {
        item[mapObj.field] = mapObj.idMaps[item[mapObj.field]] || item[mapObj.field];
      });
    }

    const createP = this.crudCreate(crud, added)
      .then(results => this.buildIdMap(results, addedItems));

    const updatedP = this.crudUpdate(crud, updated);

    return Promise.all([createP, updatedP])
      .then(results => _.assign({}, ...results));
  }

  updateItem(objectName, diffs) {
    if (diffs.length === 0) return Promise.resolve({});
    return this.httpAPI.put(objectName, diffs).then(res => res.data);
  }

  createItem(objectName, objs) {
    if (objs.length === 0) return Promise.resolve({});
    console.log(objectName, objs);
    return this.httpAPI.post(objectName, objs).then(res => res.data);
  }

  deleteItem(objectName, productDeleteIds) {
    if (productDeleteIds.length === 0) return Promise.resolve({});
    return Promise.all(productDeleteIds.map(id => this.httpAPI.delete(objectName + "/" + id)));
  }

  createUpdate(objectName, objs, mapObj) { // mapObj: {{idMaps, field: 'IncidentReportId'}}
    const {added, updated, deleted, addedItems, updatedItems} = managedItemsToObject(objs);

    if (mapObj) {
      added.forEach(item => {
        item[mapObj.field] = mapObj.idMaps[item[mapObj.field]] || item[mapObj.field];
      });
    }

    const createP = this.createItem(objectName, added)
      .then(results => this.buildIdMap(results, addedItems));

    const updatedP = this.updateItem(objectName, updated)
      .then(results => this.buildIdMap(results, updatedItems));

    return Promise.all([createP, updatedP])
      .then(results => _.assign({}, ...results));
  }

  createUpdateDelete(objectName, objs) {
    const {added, updated, deleted, addedItems, updatedItems} = managedItemsToObject(objs);

    const createP = this.createItem(objectName, added)
      .then(results => this.buildIdMap(results, addedItems));

    const updatedP = this.updateItem(objectName, updated)
      .then(results => this.buildIdMap(results, updatedItems));

    const deleteP = this.deleteItem(objectName, deleted);

    return Promise.all([createP, updatedP, deleteP])
      .then(results => _.assign({}, ...results));
  }

  buildIdMap(results, sources) {
    return _.zip(results, sources).map(([result, sourceItem]) => {
      if (!result.success) {
        throw new Error('Failed to create entry: ' + JSON.stringify(sourceItem, null, 2));
      }

      return {[sourceItem.UID]: result.UID};

    })
      .reduce((acc, e) => _.assign(acc, e), {});
  }

  fetchAttachmentLists(jobIds) {
    const attachmentPromises = jobIds.map(id => {
      return this.http.get(`/attachments/${id}`)
        .then(res => res.data)
        .then(data => {
          const attachmentList = [];
          data.map(attachment => {
            attachmentList.push({
              name: attachment.fileName,
              definition: attachment,
              UID: attachment.filePtr,
              parentId: attachment.parentId
            });
          });

          return attachmentList;
        });
    });

    return Promise.all(attachmentPromises)
      .then(res => _.flatten(_.toArray(res)));
  };

  fetchAttachmentData(attachmentList) {
    return Promise.all(attachmentList.map(attachment => {
      const fetchUrl = `/attachment/${attachment.definition.filePtr}`;
      return this.fetchAsDataURI(fetchUrl, this.http).then(base64 => {
        attachment.attachment = base64;
        return attachment;
      }, error => attachment);
    }));
  }

  fetchAttachments(parentIds) {
    const selectAttachments = (id, data) => {
      const validSignatures = data
      // .filter(item => true)
        .map(item => {
          item.timestamp = (new Date(item.uploadDate)).getTime();
          return item;
        })
        .sort((a, b) => b.timestamp - a.timestamp);

      return _.map(validSignatures, item => {
        return {
          name: item.fileName,
          parentId: id,
          definition: item,
          UID: item.filePtr
        };
      });
    };
    const propmisesItems = (data) => {
      return data.map(item => {
        const fetchUrl = `/attachment/${item.definition.filePtr}`;
        return this.fetchAsDataURI(fetchUrl, this.http)
          .then(base64 => {
            item.attachment = base64;
            return item;
          });
      });
    };
    const promises = parentIds.map(id => {
      return this.http.get(`/attachments/${id}`)
        .then(({data}) => selectAttachments(id, data))
        .then(items => propmisesItems(items))
        .then(res => ({
          [id]: res
        }));
    });

    return Promise.all(promises)
      .then(res => {
        const flow = _.flow([_.toArray, _.flatten]);
        const lstPromise = res.reduce((acc, e) => _.assign(acc, e), {});
        return Promise.all(flow(lstPromise));
      });
  }

  saveAttachments(attachments, idMaps) {
    const {added, deleted} = managedItemsToObject(attachments);

    let newAttachments = added;
    if (idMaps) {
      newAttachments = attachments.map(attachment => {
        attachment.parentId = idMaps[attachment.parentId] || attachment.parentId;
        return attachment;
      });
    }

    const deletedOlds = deleted.map(id => this.http.delete('/delattachment/' + id));
    const promises = newAttachments.map(item => {

      const {parentId, name, attachment, description} = item;

      const body = {
        parent_id: parentId,
        name: name,
        data: attachment
      };

      if (description) body.description = description;

      if (!!item.UID && !item.UID.includes("dynamic")) {
        // deletedOlds.push(this.http.delete('/delattachment/' + item.UID));
      }

      return this.http.post(`/upload`, body).then(res => res.data);
    });

    return Promise.all(deletedOlds).then(() => Promise.all(promises));
  }

  deleteAttachments(attachments) {
    const deleteAttachments = attachments.map(item => this.http.delete('/delattachment/' + item));
    return Promise.all(deleteAttachments);
  }

  /*
	return an ISO string list, don't count holiday
	 */
  getNextFewDays(days, timezone, holidays = [], dateFormat = 'YYYY-MM-DD') {
    let result = [];
    let pointer = moment.tz(timezone).startOf('day');
    let strDay = '';

    while (result.length < days) {
      strDay = pointer.format(dateFormat);
      if (holidays.indexOf(strDay) === -1) {
        result.push(pointer.toISOString());
      }
      pointer.add(1, 'd');
    }

    // sort array
    return result.sort((a, b) => new Date(a).valueOf() - new Date(b).valueOf());
  }

  fetchJobsInRange(numberOfDays, timezone, filterText = "", filterData = [], holidays = [], dateFormat = 'YYYY-MM-DD', withFields) {
    const days = this.getNextFewDays(numberOfDays, timezone, holidays); // ISO string
    const formatDays = days.map(item => moment.tz(item, timezone).format(dateFormat)); // date format
    const min = moment(formatDays[0]).startOf('day');
    const max = moment(formatDays[formatDays.length - 1]).endOf('day');
    const firstPosition = filterData.length + 1;
    const secondPosition = filterData.length + 2;

    filterText = filterText ? "AND " + filterText : "";

    return this.fetchData("Jobs", `Start >= $${firstPosition} AND Start <= $${secondPosition} ${filterText}`, filterData.concat([min, max]), withFields || "");
  }

  // error logs
  queryErrorHandler(jobIds, error) {
    const logTimestamp = Date.now();
    return this.logError(logTimestamp, jobIds, JSON.stringify(error, Object.getOwnPropertyNames(error)))
      .then(() => this.buildErrorStruct(jobIds, logTimestamp));
  }

  buildErrorStruct(jobIds, logTimestamp) {
    const retObj = jobIds
      .map(jobId => {
        const obj = {
          error: logTimestamp
        };

        return {[jobId]: obj};
      })
      .reduce((acc, e) => _.assign(acc, e), {});

    return {
      main: retObj,
      common: {}
    };
  }

  logError(logTimestamp, jobIds, error) {

    const logData = {
      affectedJobs: jobIds,
      error: error
    };

    const logBody = JSON.stringify(logData);
    const logTitle = "CUSTOM FORM - ERROR - TIMESTAMP: " + logTimestamp;

    return this.createLog(logTitle, logBody, "Error");
  }

  createLog(title, body, type) {
    const logObject = {
      Body: body,
      Title: title,
      Type: type
    };

    return this.httpAPI.post("ExceptionLogs", [logObject]);
  }

  // utils function
  static getTimeValue(dateTime, zone) {
    const gap = moment.tz(zone).utcOffset() - moment().utcOffset();
    return moment(dateTime).add(gap, 'm');
  }

  static setTimeValue(dateTime, zone, format) {
    const gap = moment.tz(zone).utcOffset() - moment().utcOffset();
    const formattedValue = moment(dateTime).subtract(gap, 'm').format(format);
    return moment.tz(formattedValue, format, zone).toISOString();
  }

  static base64ToString(str) {
    if (typeof Buffer !== "undefined") {
      return Buffer.from(str, 'base64').toString();
    } else if (atob) {
      return atob(str);
    }

    throw new Error('Cannot transform base64 to string');
  }

  static binaryToBase64(binary) {
    return new Promise(resolve => {
      const blob = new Blob([binary], {type: 'image/png'});
      const reader = new FileReader();
      reader.onload = function () {
        const dataUrl = reader.result;
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };
      reader.readAsDataURL(blob);
    });
  }
}
