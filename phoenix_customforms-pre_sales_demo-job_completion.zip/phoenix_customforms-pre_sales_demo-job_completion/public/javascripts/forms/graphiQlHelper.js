import _ from 'lodash';
import {managedItemsToObject, PermissionsService} from '@skedulo/uranium';
import {Request, APIRequest} from '@skedulo/uranium'

if (!global || !global._babelPolyfill) {
  require('babel-polyfill')
}

const insertAt = (str, index, replacement) => {
  const oldStr = str
  const idx = str.indexOf('(')
  if (idx > -1) {
    return oldStr.substr(0, index + 1) + replacement + "," + oldStr.substr(index + 1);
  }

  return oldStr.substr(0, index) + "(" + replacement + ")" + oldStr.substr(index);
}

export default class GraphiQLHelper {
  constructor(httpAPI, http) {
    this.httpAPI = httpAPI || APIRequest("/api");
    this.http = http || Request("");
    this.isLocalhost = false;
  }

  executeQuery(query, variables) {
    return this.http.post(`graphql/graphql`, {query, variables})
      .catch(e => this.http.post(`graphql/graphql`, {query, variables}, {baseURL: '/'}))
  }

  query(query, variables) {
    const formatResponseData = (res) => {
      if (res.status === 200) {
        const {data} = res.data;
        return _.keys(data).reduce((result, key, idx) => {
          result[key] = data[key].edges.map(item => item.node);
          return result;
        }, {});
      } else {
        return {};
      }
    }
    return this.executeQuery(query, variables)
      .then(res => formatResponseData(res))
  }

  formatResponseData(responseData) {
    const {data} = responseData;
    return _.keys(data).reduce((result, key, idx) => {
      result[key] = data[key].edges.map(item => item.node);
      return result;
    }, {});
  }

  async bulkQuery(query, variables) {
    const queryAction = (_query, _variables) => {
      const queryStr = ['query {', ..._query, '}'].join('')
      return this.executeQuery(queryStr, _variables);
    };

    let result = {};
    let continueLoop = true;

    let executeQuery = [...query];
    while (continueLoop) {
      let _result = await queryAction(executeQuery, variables)
      const data = _result.data.data;

      const needMoreQuery = _.keys(data).reduce((newQueries, key) => {
        if (data[key].pageInfo.hasNextPage) {
          const allItems = data[key].edges;
          const _query = query.find(q => q.slice(0, key.length) === key);
          const {cursor} = allItems[allItems.length - 1]; // last cursor
          newQueries.push(insertAt(_query, key.length, `after: "${cursor}"`))
        }
        result[key] = (result[key] || []).concat(data[key])
        return newQueries
      }, []);

      executeQuery = [...needMoreQuery]
      continueLoop = executeQuery.length !== 0;
    }

    return  _.keys(result).reduce((dataResult, key, idx) => {
      dataResult[key] = _.flatten(result[key].map(item => item.edges)).map(item => item.node)
      return dataResult;
    }, {});
  }

  executeBulkMutation(mutations) {
    return this.http.post(`graphql/graphql/batch`, mutations)
      .catch(e => this.http.post(`graphql/graphql/batch`, mutations, {baseURL: '/'}))
  }

  mutationFactory(objName, changset) {
    const {added, updated} = managedItemsToObject(changset);
    let arrMutations = [];

    if (updated.length) {
      const updatedQuery = `mutation ($${objName}Input: Update${objName}!) {
          schema {
            update${objName}(input: $${objName}Input)
          }
        }`
      updated.forEach(updatedItem => {
        arrMutations.push({
          query: updatedQuery,
          variables: {
            [`${objName}Input`]: updatedItem
          }
        })
      })
    }

    if (added.length) {
      const addedQuery = `mutation ($${objName}Input: New${objName}!) {
        schema {
          insert${objName}(input: $${objName}Input)
        }
      }`;

      added.forEach(addedItem => {
        arrMutations.push({
          query: addedQuery,
          variables: {
            [`${objName}Input`]: addedItem
          }
        })
      })
    }

    return arrMutations;
  }
}
