export const dateFormat = 'YYYY-MM-DD';
export const dateTimeFormat = 'DD/MM/YYYY HH:mma';
export const datetimeLocalFormat = "YYYY-MM-DDTHH:mm";
export const transitionGroup = {
  transitionName: "slide",
  transitionEnterTimeout: 500,
  transitionAppearTimeout: 450,
  transitionLeaveTimeout: 0.00000001
};
