// UI action
import * as constant from "./constant";
import {LayoutAction, LayoutServiceSync} from "@skedulo/uranium/dist/index";

export const getTimeValue = (dateTime, zone) => {
  const gap = moment.tz(zone).utcOffset() - moment().utcOffset();
  return moment(dateTime).add(gap, 'm');
};

export const setTimeValue = (dateTime, zone, format) => {
  const gap = moment.tz(zone).utcOffset() - moment().utcOffset();
  const formattedValue = moment(dateTime).subtract(gap, 'm').format(format);
  return moment.tz(formattedValue, format, zone).toISOString();
};

export const correctDate = (date, format = constant.DateFormat) => {
  return moment(date, 'YYYY-MM-DD').format(format);
};

export const stripHtml = (html) => {
  // Create a new div element
  const temporalDivElement = document.createElement("div");
  // Set the HTML content with the providen
  temporalDivElement.innerHTML = html;
  // Retrieve the text property of the element (cross-browser support)
  return temporalDivElement.textContent || temporalDivElement.innerText || "";
};


// https://stackoverflow.com/questions/47226824/iphonex-and-notch-detection
export const isIphoneX = () => {
  // Really basic check for the ios platform
  // https://stackoverflow.com/questions/9038625/detect-if-device-is-ios
  const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

  // Get the device pixel ratio
  const ratio = window.devicePixelRatio || 1;

  // Define the users device screen dimensions
  const screen = {
    width : window.screen.width * ratio,
    height : window.screen.height * ratio
  };

  // iPhone X Detection
  return iOS && screen.width === 1125 && screen.height === 2436;
};

export const millisecondsToStr = (milliseconds) => {
  // TIP: to find current time in milliseconds, use:
  // var  current_time_milliseconds = new Date().getTime();

  function numberEnding (number) {
    return (number > 1) ? 's' : '';
  }

  var temp = Math.floor(milliseconds / 1000);
  var years = Math.floor(temp / 31536000);
  if (years) {
    return years + ' year' + numberEnding(years);
  }
  //TODO: Months! Maybe weeks?
  var days = Math.floor((temp %= 31536000) / 86400);
  if (days) {
    return days + ' day' + numberEnding(days);
  }
  var hours = Math.floor((temp %= 86400) / 3600);
  if (hours) {
    return hours + ' hour' + numberEnding(hours);
  }
  var minutes = Math.floor((temp %= 3600) / 60);
  if (minutes) {
    return minutes + ' minute' + numberEnding(minutes);
  }
  var seconds = temp % 60;
  if (seconds) {
    return seconds + ' second' + numberEnding(seconds);
  }
  return 'less than a second'; //'just now' //or other string you like;
};

export const getRecordTypes = (layouts, objName) => {
  const layoutService = new LayoutServiceSync(layouts);
  return layoutService.getAvailableRecordTypes(objName);
};

export const getLayoutFields = (layouts, objName, view, recordTypeId) => {
  const layoutService = new LayoutServiceSync(layouts);
  const selectedLayout = layoutService.getSingleColumnLayoutForAction(LayoutAction[view], objName, recordTypeId, true);
  // const fields = flatten(selectedLayout.map(item => item.fields));
  // console.log(fields)
  return selectedLayout;
};

export const formatPropName = (str) => {
  return str.replace(/(?:^\w|[A-Z]|\b\w)/g, word => word.toUpperCase()).replace(/\s+/g, '').replace(/,|\?|\//g, '');
};