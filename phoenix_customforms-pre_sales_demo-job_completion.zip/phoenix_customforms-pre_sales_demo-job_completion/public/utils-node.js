
export function fetchAsDataURI(url, http) {
  return Promise.resolve(http.get(url, { responseType: 'arraybuffer' }))
    .then(res => {
      const base64 = res.data.toString("base64")
      return `data:${res.headers['content-type']};base64,` + base64
    })
}
