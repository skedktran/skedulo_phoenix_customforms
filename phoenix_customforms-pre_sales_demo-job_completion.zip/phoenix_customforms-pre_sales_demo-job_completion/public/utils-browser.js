
function convertBlobToDataURI(blob) {
  return new Promise((resolve) => {

    const reader = new FileReader()

    reader.onloadend = () => {
      resolve(reader.result)
    }

    reader.readAsDataURL(blob)

  })
}

export function fetchAsDataURI(url, http) {
  return Promise.resolve(http.get(url, { responseType: 'blob' }))
  .then(({ data }) => convertBlobToDataURI(data))
}